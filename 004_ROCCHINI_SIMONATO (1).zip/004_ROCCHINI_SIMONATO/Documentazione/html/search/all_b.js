var searchData=
[
  ['s_5fnode',['s_node',['../structs__node.html',1,'']]],
  ['s_5fnode_5flist',['s_node_list',['../structs__node__list.html',1,'']]],
  ['set_5fboard_5fvalue',['set_board_value',['../group___ausiliarie.html#ga39c663b743546e37a5bbb2f9d1adfd2b',1,'set_board_value(pedina **board, point p, pedina *value):&#160;ml_lib.c'],['../group___ausiliarie.html#ga39c663b743546e37a5bbb2f9d1adfd2b',1,'set_board_value(pedina **board, point p, pedina *value):&#160;ml_lib.c']]],
  ['set_5fgrade',['set_grade',['../group___ausiliarie.html#ga663d3a2fcf86042d03eb834766b7adea',1,'set_grade(pedina *p, gr value):&#160;ml_lib.c'],['../group___ausiliarie.html#ga663d3a2fcf86042d03eb834766b7adea',1,'set_grade(pedina *p, gr value):&#160;ml_lib.c']]],
  ['set_5fid_5fplayer',['set_id_player',['../group___ausiliarie.html#gabbdcb7fca0fe313ecc63bc2ba1a73d8e',1,'set_id_player(pedina *p, id_p value):&#160;ml_lib.c'],['../group___ausiliarie.html#gabbdcb7fca0fe313ecc63bc2ba1a73d8e',1,'set_id_player(pedina *p, id_p value):&#160;ml_lib.c']]],
  ['success_5finput',['success_input',['../ml__main_8c.html#aa16e2dc3b93a313e16f909ba7521fc6a',1,'ml_main.c']]],
  ['success_5fmove',['success_move',['../ml__main_8c.html#a19663b3bb8d500407f3ae1ebe112bd25',1,'ml_main.c']]]
];
