var searchData=
[
  ['get_5fboard_5fvalue',['get_board_value',['../group___ausiliarie.html#gacbcceb01143b3098ac3ee65642d94a35',1,'get_board_value(pedina **board, point p):&#160;ml_lib.c'],['../group___ausiliarie.html#gacbcceb01143b3098ac3ee65642d94a35',1,'get_board_value(pedina **board, point p):&#160;ml_lib.c']]],
  ['get_5fboard_5fvalue_5fdown',['get_board_value_down',['../group___ausiliarie.html#gacde6d4e847576a401af96d1d84733533',1,'get_board_value_down(pedina **board, point p):&#160;ml_lib.c'],['../group___ausiliarie.html#gacde6d4e847576a401af96d1d84733533',1,'get_board_value_down(pedina **board, point p):&#160;ml_lib.c']]],
  ['get_5fboard_5fvalue_5fimmediate',['get_board_value_immediate',['../group___ausiliarie.html#ga7abcaeb9a9964698ffa11f5f86805909',1,'get_board_value_immediate(pedina **board, int x, int y):&#160;ml_lib.c'],['../group___ausiliarie.html#ga7abcaeb9a9964698ffa11f5f86805909',1,'get_board_value_immediate(pedina **board, int x, int y):&#160;ml_lib.c']]],
  ['get_5fboard_5fvalue_5fmiddle',['get_board_value_middle',['../group___ausiliarie.html#ga1e5f458cec21fb109ef5cff56b57f389',1,'get_board_value_middle(pedina **board, point p):&#160;ml_lib.c'],['../group___ausiliarie.html#ga1e5f458cec21fb109ef5cff56b57f389',1,'get_board_value_middle(pedina **board, point p):&#160;ml_lib.c']]],
  ['get_5fdir',['get_dir',['../ml__autoplay_8h.html#adf3d205b5be0c4b5111c7a5842d35fe1',1,'ml_autoplay.c']]],
  ['get_5ffrom_5flist',['get_from_list',['../ml__autoplay_8h.html#ad91c25fcffb5554e913beac89907bf2d',1,'ml_autoplay.c']]],
  ['get_5fgrade',['get_grade',['../group___ausiliarie.html#ga6ceb2e2fb4d39456d2b64b64f4841c67',1,'get_grade(pedina *p):&#160;ml_lib.c'],['../group___ausiliarie.html#ga6ceb2e2fb4d39456d2b64b64f4841c67',1,'get_grade(pedina *p):&#160;ml_lib.c']]],
  ['get_5fid_5fplayer',['get_id_player',['../group___ausiliarie.html#gaeebe06189e2bd221a0e65b7d15f6b1b5',1,'get_id_player(pedina *p):&#160;ml_lib.c'],['../group___ausiliarie.html#gaeebe06189e2bd221a0e65b7d15f6b1b5',1,'get_id_player(pedina *p):&#160;ml_lib.c']]],
  ['get_5fmoves',['get_moves',['../ml__autoplay_8h.html#a322f2a61d1002e217404485376dc71a6',1,'ml_autoplay.c']]],
  ['getdepth',['getDepth',['../group___input.html#ga32c2be1375cecfcc38264f7c4cd05994',1,'getDepth(void):&#160;ml_lib.c'],['../group___input.html#ga32c2be1375cecfcc38264f7c4cd05994',1,'getDepth(void):&#160;ml_lib.c']]],
  ['getmode',['getMode',['../group___input.html#ga864e133c77eff70f91c1fa13b12046e6',1,'getMode(void):&#160;ml_lib.c'],['../group___input.html#ga864e133c77eff70f91c1fa13b12046e6',1,'getMode(void):&#160;ml_lib.c']]],
  ['gr',['gr',['../ml__lib_8h.html#a25f6e8adc446355e3f42092ecf9d598c',1,'ml_lib.h']]],
  ['gradecheck',['gradeCheck',['../group___logiche.html#ga92e065216878c6972f25bb40cede5a3f',1,'gradeCheck(pedina **board, point from, point to):&#160;ml_lib.c'],['../group___logiche.html#ga92e065216878c6972f25bb40cede5a3f',1,'gradeCheck(pedina **board, point from, point to):&#160;ml_lib.c']]],
  ['grado',['grado',['../structcella.html#a79404d480b96b227ce1fca8cfca5ea66',1,'cella']]]
];
