var searchData=
[
  ['punto',['punto',['../structpunto.html',1,'']]]
];
