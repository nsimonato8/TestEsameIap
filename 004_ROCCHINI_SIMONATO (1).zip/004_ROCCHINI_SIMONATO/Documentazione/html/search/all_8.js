var searchData=
[
  ['main',['main',['../ml__main_8c.html#a51af30a60f9f02777c6396b8247e356f',1,'ml_main.c']]],
  ['middle',['middle',['../structcella.html#aee3fa6fae5c1685708b80a7dca8fafd7',1,'cella']]],
  ['minimax',['minimax',['../ml__autoplay_8h.html#a2dde1a738d42f10de8ca818976b53635',1,'ml_autoplay.c']]],
  ['ml_5fautoplay_2eh',['ml_autoplay.h',['../ml__autoplay_8h.html',1,'']]],
  ['ml_5flib_2eh',['ml_lib.h',['../ml__lib_8h.html',1,'']]],
  ['ml_5fmain_2ec',['ml_main.c',['../ml__main_8c.html',1,'']]],
  ['mod',['mod',['../ml__autoplay_8h.html#a4b97eb97db2365148a5c3a5070f0cdd1',1,'ml_autoplay.h']]],
  ['mode',['mode',['../ml__autoplay_8h.html#a2a5b40289f6fafabc17ca8ef5db14070',1,'mode():&#160;ml_autoplay.h'],['../ml__main_8c.html#a40587174746705895d5f71ba308fc02d',1,'Mode():&#160;ml_main.c']]],
  ['moveerror',['moveError',['../group___output.html#ga6d8a8483d8971d69c75aea3630453524',1,'moveError(pedina **board, int cord[4], int turn):&#160;ml_lib.c'],['../group___output.html#ga6d8a8483d8971d69c75aea3630453524',1,'moveError(pedina **board, int cord[4], int turn):&#160;ml_lib.c']]],
  ['moves',['moves',['../ml__main_8c.html#ac99a41b8663e7eb9a2ebeeb12f6a0e31',1,'ml_main.c']]],
  ['my_5fmove',['my_move',['../group___logiche.html#gac0ab070447e0245797db89513aac7464',1,'my_move(pedina **b, point from, point to, int turn):&#160;ml_lib.c'],['../group___logiche.html#gac0ab070447e0245797db89513aac7464',1,'my_move(pedina **board, point from, point to, int turn):&#160;ml_lib.c']]]
];
