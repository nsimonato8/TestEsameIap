var searchData=
[
  ['x',['x',['../structpunto.html#a258126d731de858fa7dc4a24f83c3f7d',1,'punto']]]
];
