var searchData=
[
  ['right_5fpath',['right_path',['../group___ausiliarie.html#ga3fb77572cfa3beeebef9bbf9c5170a0d',1,'right_path(dir direction, gr grade, id_p player):&#160;ml_lib.c'],['../group___ausiliarie.html#ga3fb77572cfa3beeebef9bbf9c5170a0d',1,'right_path(dir direction, gr grade, id_p player):&#160;ml_lib.c']]]
];
