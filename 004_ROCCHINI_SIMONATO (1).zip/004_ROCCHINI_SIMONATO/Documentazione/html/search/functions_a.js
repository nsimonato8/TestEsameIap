var searchData=
[
  ['set_5fboard_5fvalue',['set_board_value',['../group___ausiliarie.html#ga39c663b743546e37a5bbb2f9d1adfd2b',1,'set_board_value(pedina **board, point p, pedina *value):&#160;ml_lib.c'],['../group___ausiliarie.html#ga39c663b743546e37a5bbb2f9d1adfd2b',1,'set_board_value(pedina **board, point p, pedina *value):&#160;ml_lib.c']]],
  ['set_5fgrade',['set_grade',['../group___ausiliarie.html#ga663d3a2fcf86042d03eb834766b7adea',1,'set_grade(pedina *p, gr value):&#160;ml_lib.c'],['../group___ausiliarie.html#ga663d3a2fcf86042d03eb834766b7adea',1,'set_grade(pedina *p, gr value):&#160;ml_lib.c']]],
  ['set_5fid_5fplayer',['set_id_player',['../group___ausiliarie.html#gabbdcb7fca0fe313ecc63bc2ba1a73d8e',1,'set_id_player(pedina *p, id_p value):&#160;ml_lib.c'],['../group___ausiliarie.html#gabbdcb7fca0fe313ecc63bc2ba1a73d8e',1,'set_id_player(pedina *p, id_p value):&#160;ml_lib.c']]]
];
