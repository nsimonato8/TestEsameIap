var searchData=
[
  ['pedina',['pedina',['../ml__lib_8h.html#a71fee95122b31f5cb0b07d9c16ffa3a5',1,'ml_lib.h']]],
  ['point',['point',['../ml__lib_8h.html#a451dd2984edbf81c9db421e898b39ef9',1,'ml_lib.h']]],
  ['prepend',['prepend',['../ml__autoplay_8h.html#a30189b8f3988a507ca2c368b03ff3a46',1,'ml_autoplay.c']]],
  ['print_5flist',['print_list',['../ml__autoplay_8h.html#ad21eb4909ab1c3d08bd8af2d4bc5a7a7',1,'ml_autoplay.c']]],
  ['print_5ft_5fnode',['print_t_node',['../ml__autoplay_8h.html#aa434d88621f2b5514f99e17ffaadfd5b',1,'ml_autoplay.c']]],
  ['printmatrix',['printMatrix',['../group___output.html#gac5423849c2701b9adbd33225a8a20288',1,'printMatrix(pedina **board):&#160;ml_lib.c'],['../group___output.html#gac5423849c2701b9adbd33225a8a20288',1,'printMatrix(pedina **board):&#160;ml_lib.c']]],
  ['printpedina',['printPedina',['../group___output.html#ga724261d45664de95115edbec3fec7aef',1,'printPedina(pedina *p):&#160;ml_lib.c'],['../group___output.html#ga724261d45664de95115edbec3fec7aef',1,'printPedina(pedina *p):&#160;ml_lib.c']]],
  ['printrules',['printRules',['../group___output.html#ga24e7114025f82d3a3a186743a6e5799f',1,'printRules():&#160;ml_lib.c'],['../group___output.html#ga24e7114025f82d3a3a186743a6e5799f',1,'printRules(void):&#160;ml_lib.c']]],
  ['printstatus',['printStatus',['../group___output.html#gab1b6c72fb86f8d1c4537fec2456e4c78',1,'printStatus(int turn):&#160;ml_lib.c'],['../group___output.html#gab1b6c72fb86f8d1c4537fec2456e4c78',1,'printStatus(int turn):&#160;ml_lib.c']]],
  ['punto',['punto',['../structpunto.html',1,'']]]
];
