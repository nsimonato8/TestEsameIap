var indexSectionsWithContent =
{
  0: "abcdefgimprstvxy",
  1: "cps",
  2: "m",
  3: "acdefgimprsv",
  4: "bcdfgimstxy",
  5: "mpt",
  6: "dgim",
  7: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "groups"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Strutture dati",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Ridefinizioni di tipo (typedef)",
  6: "Tipi enumerati (enum)",
  7: "Gruppi"
};

