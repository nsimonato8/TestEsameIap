var searchData=
[
  ['can_5fbe_5featen',['can_be_eaten',['../ml__autoplay_8h.html#a9c6aa7ebae169d372e643db2c28b4555',1,'ml_autoplay.c']]],
  ['can_5feat',['can_eat',['../group___logiche.html#gae47a85e51124bf1b5569559ba5718bb6',1,'can_eat(pedina **board, point p):&#160;ml_lib.c'],['../group___logiche.html#gae47a85e51124bf1b5569559ba5718bb6',1,'can_eat(pedina **board, point p):&#160;ml_lib.c']]],
  ['can_5fmove',['can_move',['../group___logiche.html#ga8cc7e93c7f87a22d21412b3ca1f942e6',1,'can_move(pedina **board, point p):&#160;ml_lib.c'],['../group___logiche.html#ga8cc7e93c7f87a22d21412b3ca1f942e6',1,'can_move(pedina **board, point p):&#160;ml_lib.c']]],
  ['capture',['capture',['../group___logiche.html#ga373ce247f8d712b22dd6db6b5aaeb77c',1,'capture(pedina **b, point from, point to):&#160;ml_lib.c'],['../group___logiche.html#ga373ce247f8d712b22dd6db6b5aaeb77c',1,'capture(pedina **board, point from, point to):&#160;ml_lib.c']]],
  ['catchinput',['catchInput',['../group___input.html#ga6c1be53f2fdc0713f70686d579664a26',1,'ml_lib.h']]],
  ['catchinput_5fautoplay',['catchInput_Autoplay',['../ml__autoplay_8h.html#afb196dfa912887a9d6deebbec6dacfde',1,'ml_autoplay.c']]],
  ['clonematrix',['cloneMatrix',['../group___memoria.html#gac12fcc7dd33c1d2dbad5b1485988329a',1,'cloneMatrix(pedina **board):&#160;ml_lib.c'],['../group___memoria.html#gac12fcc7dd33c1d2dbad5b1485988329a',1,'cloneMatrix(pedina **board):&#160;ml_lib.c']]],
  ['creatematrix',['createMatrix',['../group___memoria.html#gab9607896ed7aebf86c8a7ac51fe5a618',1,'createMatrix():&#160;ml_lib.c'],['../group___memoria.html#gab9607896ed7aebf86c8a7ac51fe5a618',1,'createMatrix(void):&#160;ml_lib.c']]]
];
