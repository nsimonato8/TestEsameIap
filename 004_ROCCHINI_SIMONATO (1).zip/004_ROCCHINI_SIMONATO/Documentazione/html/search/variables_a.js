var searchData=
[
  ['y',['y',['../structpunto.html#a31195a01422c6e9574235d9b0bf8d285',1,'punto']]]
];
