var searchData=
[
  ['depth',['Depth',['../ml__main_8c.html#ac66dbe0e082fd3cc29bc1572a4dccc09',1,'ml_main.c']]],
  ['destroy_5flist',['destroy_list',['../ml__autoplay_8h.html#addc0aeed0f8c87521bec3564f23aa20f',1,'ml_autoplay.c']]],
  ['destroymatrix',['destroyMatrix',['../group___memoria.html#ga898a4ffd57725b4666aa768ca71f1e1f',1,'destroyMatrix(pedina **board):&#160;ml_lib.c'],['../group___memoria.html#ga898a4ffd57725b4666aa768ca71f1e1f',1,'destroyMatrix(pedina **board):&#160;ml_lib.c']]],
  ['dir',['dir',['../ml__lib_8h.html#a4ca269cf93df1b512b52174c1a256fe5',1,'ml_lib.h']]],
  ['distance',['distance',['../group___logiche.html#gabcbd7b41508ab908b601d6607330190f',1,'distance(point from, point to):&#160;ml_lib.c'],['../group___logiche.html#gabcbd7b41508ab908b601d6607330190f',1,'distance(point from, point to):&#160;ml_lib.c']]],
  ['down',['down',['../structcella.html#a91897ce70af7b66dfca5de2141a8718d',1,'cella']]]
];
