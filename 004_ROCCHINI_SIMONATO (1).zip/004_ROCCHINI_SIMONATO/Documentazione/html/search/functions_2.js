var searchData=
[
  ['destroy_5flist',['destroy_list',['../ml__autoplay_8h.html#addc0aeed0f8c87521bec3564f23aa20f',1,'ml_autoplay.c']]],
  ['destroymatrix',['destroyMatrix',['../group___memoria.html#ga898a4ffd57725b4666aa768ca71f1e1f',1,'destroyMatrix(pedina **board):&#160;ml_lib.c'],['../group___memoria.html#ga898a4ffd57725b4666aa768ca71f1e1f',1,'destroyMatrix(pedina **board):&#160;ml_lib.c']]],
  ['distance',['distance',['../group___logiche.html#gabcbd7b41508ab908b601d6607330190f',1,'distance(point from, point to):&#160;ml_lib.c'],['../group___logiche.html#gabcbd7b41508ab908b601d6607330190f',1,'distance(point from, point to):&#160;ml_lib.c']]]
];
