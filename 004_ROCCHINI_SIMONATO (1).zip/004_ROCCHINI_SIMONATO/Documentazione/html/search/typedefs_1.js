var searchData=
[
  ['pedina',['pedina',['../ml__lib_8h.html#a71fee95122b31f5cb0b07d9c16ffa3a5',1,'ml_lib.h']]],
  ['point',['point',['../ml__lib_8h.html#a451dd2984edbf81c9db421e898b39ef9',1,'ml_lib.h']]]
];
