var searchData=
[
  ['evaluate',['evaluate',['../ml__autoplay_8h.html#adda300b56a27381dec16da8891d8c2d4',1,'ml_autoplay.c']]],
  ['existmandatory',['existMandatory',['../group___logiche.html#gaf5deae59415fab0cf7de74362d4b56e6',1,'existMandatory(pedina **board, point from, point to):&#160;ml_lib.c'],['../group___logiche.html#gaf5deae59415fab0cf7de74362d4b56e6',1,'existMandatory(pedina **board, point from, point to):&#160;ml_lib.c']]]
];
