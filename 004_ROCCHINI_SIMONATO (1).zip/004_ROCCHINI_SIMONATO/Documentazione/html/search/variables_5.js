var searchData=
[
  ['id_5fplayer',['id_player',['../structcella.html#a7cf7cebae17473f8d52d515a2a400dfe',1,'cella']]]
];
