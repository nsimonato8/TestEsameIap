var searchData=
[
  ['grado',['grado',['../structcella.html#a79404d480b96b227ce1fca8cfca5ea66',1,'cella']]]
];
