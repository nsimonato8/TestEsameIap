var searchData=
[
  ['main',['main',['../ml__main_8c.html#a51af30a60f9f02777c6396b8247e356f',1,'ml_main.c']]],
  ['minimax',['minimax',['../ml__autoplay_8h.html#a2dde1a738d42f10de8ca818976b53635',1,'ml_autoplay.c']]],
  ['moveerror',['moveError',['../group___output.html#ga6d8a8483d8971d69c75aea3630453524',1,'moveError(pedina **board, int cord[4], int turn):&#160;ml_lib.c'],['../group___output.html#ga6d8a8483d8971d69c75aea3630453524',1,'moveError(pedina **board, int cord[4], int turn):&#160;ml_lib.c']]],
  ['my_5fmove',['my_move',['../group___logiche.html#gac0ab070447e0245797db89513aac7464',1,'my_move(pedina **b, point from, point to, int turn):&#160;ml_lib.c'],['../group___logiche.html#gac0ab070447e0245797db89513aac7464',1,'my_move(pedina **board, point from, point to, int turn):&#160;ml_lib.c']]]
];
