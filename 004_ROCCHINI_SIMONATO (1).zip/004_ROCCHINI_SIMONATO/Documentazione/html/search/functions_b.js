var searchData=
[
  ['victory',['victory',['../group___output.html#ga126ef35a3cacdc550c03a737bf1311bf',1,'victory(id_p winner):&#160;ml_lib.c'],['../group___output.html#ga126ef35a3cacdc550c03a737bf1311bf',1,'victory(id_p winner):&#160;ml_lib.c']]]
];
