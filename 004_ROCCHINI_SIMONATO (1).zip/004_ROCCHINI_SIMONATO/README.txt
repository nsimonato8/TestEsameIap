NUMERO GRUPPO: "GRUPPO 4"

MEMBRI GRUPPO: 
	- Rocchini Giovanni, 876190;
	- Niccolò Simonato, 879993 ;